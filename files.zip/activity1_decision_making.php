<?php
/*
 * Laboratory Activity 1: Decision-Making Program
 * Objective: Practice using if, elseif, and else statements.
 *
 * Receives a student's numerical score and displays the remark:
 *   90-100 : Excellent
 *   80-89  : Very Good
 *   75-79  : Passed
 *   Below 75 : Failed
 * Extension: validates that the score is between 0 and 100.
 */

$score = null;
$result = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $input = trim($_POST["score"] ?? "");

    // Extension: validation (must be a number from 0 to 100)
    if ($input === "" || !is_numeric($input)) {
        $result = "Invalid input. Please enter a number.";
    } else {
        $score = (float) $input;

        if ($score < 0 || $score > 100) {
            $result = "Invalid score. The score must be between 0 and 100.";
        } elseif ($score >= 90) {
            $result = "Excellent";
        } elseif ($score >= 80) {
            $result = "Very Good";
        } elseif ($score >= 75) {
            $result = "Passed";
        } else {
            $result = "Failed";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Activity 1: Decision-Making Program</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 420px; margin: 40px auto; }
        input, button { padding: 8px; font-size: 16px; }
        .result { margin-top: 20px; padding: 12px; background: #eef4fb; border-left: 4px solid #1F4E79; }
    </style>
</head>
<body>
    <h2>Student Score Checker</h2>
    <form method="post" action="">
        <label for="score">Enter score (0-100):</label><br><br>
        <input type="text" id="score" name="score"
               value="<?php echo htmlspecialchars($_POST['score'] ?? ''); ?>">
        <button type="submit">Check</button>
    </form>

    <?php if ($result !== ""): ?>
        <div class="result">
            <?php if ($score !== null && $score >= 0 && $score <= 100): ?>
                Score: <strong><?php echo htmlspecialchars((string) $score); ?></strong><br>
            <?php endif; ?>
            Result: <strong><?php echo $result; ?></strong>
        </div>
    <?php endif; ?>
</body>
</html>
