<?php
/*
 * Laboratory Activity 2: Looping Practice
 * Objective: Practice for, while, and foreach loops.
 * Run in a browser or in the terminal:  php activity2_looping.php
 */

echo "<pre>\n";

// ---------------------------------------------------------------
// Example 1: for loop - display numbers 1 to 20
// ---------------------------------------------------------------
echo "Example 1: for loop (1 to 20)\n";
for ($i = 1; $i <= 20; $i++) {
    echo $i . " ";
}
echo "\n\n";

// ---------------------------------------------------------------
// Example 2: while loop - display the even numbers from 2 to 20
// ---------------------------------------------------------------
echo "Example 2: while loop (even numbers 2 to 20)\n";
$n = 2;
while ($n <= 20) {
    echo $n . " ";
    $n += 2;
}
echo "\n\n";

// ---------------------------------------------------------------
// Example 3: foreach loop - display five student names in an array
// ---------------------------------------------------------------
echo "Example 3: foreach loop (student names)\n";
$students = ["Juan", "Maria", "Pedro", "Ana", "Jose"];
foreach ($students as $name) {
    echo $name . "\n";
}
echo "\n";

// ---------------------------------------------------------------
// Challenge: Example 3 modified to use continue and break
//   - continue skips "Pedro"
//   - break stops the loop when "Ana" is reached
// ---------------------------------------------------------------
echo "Challenge: foreach with continue and break\n";
foreach ($students as $name) {
    if ($name === "Pedro") {
        continue;          // skip Pedro and go to the next name
    }
    if ($name === "Ana") {
        break;             // stop the loop completely at Ana
    }
    echo $name . "\n";
}

echo "</pre>\n";
